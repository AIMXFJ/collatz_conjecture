/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collatz;

import java.util.Scanner;

/**
 *
 * @author AIMX
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Creates collatz object
        Collatz collatz = new Collatz();

        //Prepares scanner to take input number
        Scanner reader = new Scanner(System.in);
        int number = 0;

        //Allows to calculate as much as you want
        while (true) {
            //Input reqesting will be done at least 1 time
            do {
                //Request input
                System.out.println("Enter a positive number (-1 to exit): ");
                //Take the input
                number = reader.nextInt();
                
                //Checks if it has to close the program
                if (number == -1) {
                    System.exit(0);
                }
            //If number is valid continues execution
            } while (number < 0);

            //Calls the calculate function
            collatz.calculateCollatz(number);
        }
    }

}
