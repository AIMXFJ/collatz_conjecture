package collatz;

/**
 *
 * @author AIMX
 */
public class Collatz {
    
    public Collatz() {
        
    }
    
    //Makes recursion until it reaches 1 and prints each step
    public void calculateCollatz(int number){
        int result = 0;
        
        if(number <= 1)                     //Checks if it needs to calculate one more time
            return;
        
        if(number % 2 == 0)             //Even number
            result = number/2;
        else                                    //Odd number
            result = 3 * number + 1;
        
        System.out.println("Step: " + result);
        calculateCollatz(result);       //Recursive call with the calculated step number
    }
    
}
