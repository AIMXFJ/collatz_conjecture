#include <stdio.h>
#include <stdlib.h>

void doCollatz(int number){
    int result = 0;
    if(number <= 1)
        return;
    if(number % 2 == 0)
        result = number/2;
    else
        result = 3 * number + 1;

    printf("Step: %d\n", result);
    doCollatz(result);
}

int main (int argc, char *argv[])
{
    int number = 0;
    while(1){
        do{
            printf ("Enter a positive number (-1 to exit): ");
            scanf ("%d", &number);
            if(number == -1)
                exit(0);
        }while(number < 0);
        printf ("Number: %d\n", number);
        doCollatz(number);
    }
    return 0;
}
